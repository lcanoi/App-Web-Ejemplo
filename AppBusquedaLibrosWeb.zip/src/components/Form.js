import React from "react"

class Form extends React.Component{
    constructor(props){
        super(props);
    }

    
    render(){
        return (
            <div {...this.props}>
                
            </div>
        )
    }
}

export default Form;