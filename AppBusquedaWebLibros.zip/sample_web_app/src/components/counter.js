import React from "react"

class Input extends React.Component{
    constructor(props){
        super(props)

        this.state = {
            counter: -1,
            monted:"En preparación",
        }
    }

    componentDidMount(){
        this.setState({mounted:"Listo"})
    }

    methodSum = () => {
        this.setState({counter: this.state.counter + 1})
    }

    methodRes = () => {
        this.setState({counter: this.state.counter - 1})
    }

    render(){
        return (
            <div>
                ({this.state.mounted})
                {this.props.label}
                <button onClick={this.methodRes}>-1</button>
                {this.state.counter}
                <button onClick={this.methodSum}>+1</button>
                {this.state.counterXZ}
            </div>
        )
    }
}

export default Counter;