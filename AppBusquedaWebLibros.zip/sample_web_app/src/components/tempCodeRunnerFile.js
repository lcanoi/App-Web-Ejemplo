({this.state.mounted})
                {this.props.label}
                <button onClick={this.methodRes}>-1</button>
                {this.state.counter}
                <button onClick={this.methodSum}>+1</button>
                {this.state.counterXZ}